**Resolución del juego**: 640x360, integer scaling.

**Descripción:** Metroidvania plataformero sencillo (inspirado en pinkheaven), con uno o dos niveles medios-largos, tres tipos de enemigo, un arma y, un jefe final.

**Trama:** Fidu se encuentra en un sueño nuboso, tendrá que contentar a los habitantes de este gracias a las burbujas que suelta.

**Pantalla de inicio:** Título centrado en la zona superior. En la zona inferior, el jugador sobre los tiles básicos del terreno del juego, puede moverse hacia la derecha o izquierda para comenzar el juego. (En un futuro, según la zona a la que se mueva debería dar lugar a dos caminos diferentes).

**Animaciones**: Cada estado del jugador solo puede tener dos imágenes.